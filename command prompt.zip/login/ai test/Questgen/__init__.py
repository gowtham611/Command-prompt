# Constructor for questgen
from __future__ import absolute_import
from Questgen.encoding import encoding
from Questgen.mcq import mcq
from Questgen.main import QGen, BoolQGen, AnswerPredictor
